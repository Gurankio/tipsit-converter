/* 
//  Weighted Codes Converter Library
//  v 1.0
//  Sushi Squad, 2019
*/

#include <iostream>
#include <string>
#include <math.h>
#include "wccl.cpp"
using namespace std;

// prototipi
string toWBase(string, string, bool);
string aiken(char);
string bcd(char);
string quinary(char);
string biquinary(char);
string twoOutOfFive(char);