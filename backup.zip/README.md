# Tipsit

## Codifiche
 Sempre passando per ~~Binario~~ / Decimale

### Numeriche
* [X] Romano
* [x] Base X a Base Y 

### Alfanumeriche
* [x] Ascii
* [x] E-Ascii
* [x] UTF-8
* [ ] UTF-16
* [ ] UTF-32

### Pesati
* [x] BCD
* [x] Aiken
* [x] Quinario
* [x] Biquinario
* [x] 2/5

### Non pesati
* [X] Eccesso 3
* [?] Gray
* [X] Eccesso 3 Riflesso
* [ ] 1 su N
* [ ] 7 Segmenti
* [ ] Matrice
