//
//  main.hpp
//  TIPSIT
//
//  Created by Gurankio on 14/05/2020.
//  Copyright © 2020 Gurankio. All rights reserved.
//

#ifndef main_hpp
#define main_hpp



#endif /* main_hpp */
